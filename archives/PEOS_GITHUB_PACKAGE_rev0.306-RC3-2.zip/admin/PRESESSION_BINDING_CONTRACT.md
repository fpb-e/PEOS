# PRESESSION BINDING CONTRACT — rev0.306-RC3

## 目的
五正本を「読める」状態と、RUNTIME_GUARDのstate machineがfirst user turn前にhostへbindされた状態を分離する。

## Required pre-session states
- `FIVE_CANON_AVAILABLE`
- `FIVE_CANON_INSPECTED`
- `RUNTIME_ACTIVE_RULES_COMPILED`
- `HOST_PRE_DISPATCH_HOOK_INSTALLED`
- `FIRST_USER_TURN_ARMED`

各stateは独立証拠を要求し、一つのTRUEから別stateのTRUEを推定しない。

## Binding receipt schema
```text
SESSION_ID
BIND_EVENT_ID
FIVE_CANON_SET_DIGEST
RUNTIME_RULESET_DIGEST
HOST_PRE_DISPATCH_HOOK_ID
HOOK_INSTALL_EVENT_ID
FIRST_USER_TURN_ARMED_AT
TRACE_SOURCE
TRACE_DIGEST
```

## Strict conformance
上記binding receiptがないhostでは`PEOS_FIVE_CANON_PRESESSION_BINDING_GAP`としてfail-closedする。
