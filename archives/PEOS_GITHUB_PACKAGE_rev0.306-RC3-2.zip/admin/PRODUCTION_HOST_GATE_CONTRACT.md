# Production Host Gate Contract — rev0.306-RC3

## Required host behavior

1. user turn境界でtime latchをLOCKEDへ再初期化する。
2. model semantic dispatch前に、唯一許可されたprovider `datetime.now(ZoneInfo("Asia/Tokyo"))` をaction index 1で実行する。
3. actual tool eventをturn-local traceへ保存する。
4. trace recordがない場合、通常回答を許可せずstrict conformanceを名乗らない。
5. receipt表示はtrace recordから生成し、model自由文から生成しない。
6. 後続turnの成功は過去turnを修復しない。

## Evidence classes

- STATIC_PACKAGE_VALIDATION: package構造・rule ownership。
- MODELLED_HARNESS: 状態機械simulation。
- CURRENT_TURN_HOST_TRACE: 現在turnの実tool transcript。
- LIVE_CLEAN_SESSION_MULTI_TURN_TRACE: 外部父レビューで取得する必須受入証跡。

`STATIC_PACKAGE_VALIDATION`または`MODELLED_HARNESS`だけではrelease acceptanceにならない。

## rev0.306-RC3 PRESESSION BINDING

strict runtimeの前提は、first user turn受領前に次の独立状態がactual host evidenceで成立していること。

```text
FIVE_CANON_AVAILABLE = TRUE
RUNTIME_ACTIVE_RULES_COMPILED = TRUE
HOST_PRE_DISPATCH_HOOK_INSTALLED = TRUE
FIRST_USER_TURN_ARMED = TRUE
```

`FIVE_CANON_INSPECTED=TRUE`は上記の代用にならない。

毎user turnではpre-dispatch hookが最初のtool actionを
`datetime.now(ZoneInfo("Asia/Tokyo"))`だけに限定する。
hook/trace/action-index保証のいずれかが欠ける場合はstrict conformanceをFAILに固定する。
