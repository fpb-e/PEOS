#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, re, sys, yaml
from datetime import datetime
from zoneinfo import ZoneInfo

RC='rev0.306-RC3'
OPERATIVE='rev0.305'
BASELINE_SHA='69c99dd788f009726d20e43522822b288fa16eef03e7e4860fb34a4f23beae66'
BASELINE_SIDECAR_SHA='daa4209b3c41ced379bd54518ee2a5edda8d39bcd1070c7df41bb6a3710249cf'
FIVE=[
 'prompt/PEOS_CURRENT_SPEC_JP.md',
 'prompt/PEOS_CURRENT_RUNTIME_GUARD_JP.md',
 'prompt/PEOS_CURRENT_DESIGNDOC_JP.md',
 'prompt/PEOS_CURRENT_PAPER_JP.md',
 'prompt/PEOS_CURRENT_LOG_ANTHOLOGY_JP.md'
]
REQUIRED=[
 *FIVE,
 'admin/RULE_OWNERSHIP_REGISTRY.yaml',
 'admin/CURRENT_TO_RC3_MIGRATION_LEDGER.jsonl',
 'admin/ACTIVE_RULE_CONFLICT_REPORT.md',
 'admin/FATHER_DIRECT_LEDGER.jsonl',
 'admin/BEHAVIOR_FIXTURE_INDEX.yaml',
 'admin/COORDINATE_OVERLAY_MAP.yaml',
 'admin/PRODUCTION_HOST_GATE_CONTRACT.md',
 'admin/PRESESSION_BINDING_CONTRACT.md',
 'admin/FAILURE_CLASS_REGISTRY.yaml',
 'admin/SOURCE_SUPERSESSION_LEDGER.md',
 'admin/BASELINE_IMMUTABILITY_EVIDENCE.txt',
 'tests/CURRENT_BUILD_TURN_ACTUAL_TRACE.json',
 'tests/FIVE_CANON_COLD_START_LIVE_TRACE.json',
 'tests/NEGATIVE_SUBSTITUTION_NO_LATE_REPAIR_RESULTS.json',
 'tests/PRODUCTION_TRACE_SCHEMA.json',
 'evidence/PEOS_EVIDENCE.txt',
 'README.md','CHANGELOG.md'
]
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1<<20),b''): h.update(c)
    return h.hexdigest()

def manifest_entries(p):
    if not p.exists(): return {},{}
    meta={}; files={}
    for line in p.read_text(encoding='utf-8').splitlines():
        if ': ' in line and not line.startswith('SHA256  '):
            k,v=line.split(': ',1); meta[k]=v
        m=re.match(r'^SHA256  ([0-9a-f]{64})  (\d+)  (.+)$',line)
        if m: files[m.group(3)]={'sha256':m.group(1),'bytes':int(m.group(2))}
    return meta,files

class Gate:
    def __init__(self, presession=True, hook=True):
        self.presession=presession; self.hook=hook
    def turn(self, fail_first=False, pre_action=None, unbound=False):
        # actual Python provider simulation; this is HARNESS, not LIVE_HOST.
        if not self.presession or not self.hook:
            return {'result':'FAIL_CLOSED','reason':'NO_PRESESSION_OR_HOOK'}
        actions=[]
        if pre_action:
            actions.append(pre_action)
        attempts=0
        if fail_first:
            attempts+=1
            # typed environment failure, no non-time intervening action
        attempts+=1
        value=datetime.now(ZoneInfo('Asia/Tokyo')).isoformat()
        actions.append('datetime.now(ZoneInfo("Asia/Tokyo"))')
        action_index=len(actions)
        if unbound:
            return {'result':'FAIL','action_index':action_index,'attempts':attempts,'unbound':True}
        if action_index != 1:
            return {'result':'FAIL','action_index':action_index,'attempts':attempts}
        return {'result':'PASS','action_index':1,'attempts':attempts,'value':value}

def run(root, check_manifest=False):
    checks={}; details={}
    def ok(name, value, detail=None):
        checks[name]=bool(value); details[name]=detail

    missing=[x for x in REQUIRED if not (root/x).is_file()]
    ok('required_files', not missing, missing)
    if missing: return checks,details,{}

    # five-canon headers + sentinel + runtime microkernel
    bad_headers=[]; bad_sentinels=[]
    for rel in FIVE:
        t=(root/rel).read_text(encoding='utf-8')
        need=[f'文書revision: `{RC}`',f'現行latest: `{RC}`',f'PACKAGE_MANIFEST_VERSION: `{RC}`',
              f'HIGHEST_EMBEDDED_REVISION: `{RC}`',f'OPERATIVE_CURRENT: `{OPERATIVE}`',
              'NOT_OPERATIVE','NOT_ACCEPTED','NOT_SELF_ACCEPTED']
        if not all(x in t for x in need): bad_headers.append(rel)
        if rel != FIVE[1] and 'BOOTSTRAP_SENTINEL / RUNTIME_GUARD_PRECEDENCE_POINTER' not in t[:2500]:
            bad_sentinels.append(rel)
    ok('five_header_triple_equality', not bad_headers, bad_headers)
    ok('four_bootstrap_sentinels', not bad_sentinels, bad_sentinels)

    runtime=(root/FIVE[1]).read_text(encoding='utf-8')
    rtokens=[
      'PRESESSION RUNTIME BINDING / INGRESS MICROKERNEL',
      'FIVE_CANON_AVAILABLE','FIVE_CANON_INSPECTED','RUNTIME_ACTIVE_RULES_COMPILED',
      'HOST_PRE_DISPATCH_HOOK_INSTALLED','FIRST_USER_TURN_ARMED',
      'CURRENT_TURN_PYTHON_RECEIPT','SEMANTIC_WORK_AUTHORIZED',
      'RUNTIME.HOST.PRESESSION_BINDING_REQUIRED',
      'RUNTIME.HOST.BINDING_STATE_SEPARATION',
      'RUNTIME.TIME.INGRESS_MICROKERNEL',
      'RUNTIME.TIME.ACTUAL_TRACE_BINDING',
      'RUNTIME.TIME.NO_LATE_REPAIR',
      'RUNTIME.LOG.PER_TURN_TIME_FIELDS_REQUIRED',
      'RUNTIME.LOG.TIME_EVIDENCE_TYPED',
      'RUNTIME.ACCEPTANCE.FIVE_CANON_COLD_START_LIVE_TRACE_REQUIRED'
    ]
    missing_tokens=[x for x in rtokens if x not in runtime]
    ok('runtime_rc3_tokens', not missing_tokens, missing_tokens)

    # one rule / one owner + full rule cards exactly once
    reg=yaml.safe_load((root/'admin/RULE_OWNERSHIP_REGISTRY.yaml').read_text(encoding='utf-8'))
    rules=reg['rules']; ids=[r['RULE_ID'] for r in rules]
    ok('unique_rule_registry', len(ids)==len(set(ids)) and all(r.get('OWNER') and r.get('STATUS')=='ACTIVE' for r in rules), len(ids))
    canon_texts=[(root/x).read_text(encoding='utf-8') for x in FIVE]
    bad_cards={}
    for rid in ids:
        c=sum(t.count(f'RULE_ID: `{rid}`') for t in canon_texts)
        if c!=1: bad_cards[rid]=c
    ok('one_full_rule_card_owner', not bad_cards, bad_cards)

    # father ledger purity + mandatory time fields
    led=[json.loads(x) for x in (root/'admin/FATHER_DIRECT_LEDGER.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
    tf=['TURN_TIME_STATUS','USER_TURN_OBSERVED_AT_JST','TIME_EVIDENCE_CLASS','TIME_AUTHORITY']
    ok('father_ledger_source_purity', all(str(x.get('SOURCE_CLASS','')).startswith('FATHER_DIRECT') for x in led), len(led))
    ok('father_ledger_time_fields', all(all(k in x for k in tf) for x in led), len(led))
    corrected=[x for x in led if x.get('SOURCE_LOCATION','').startswith('PEOS_father_session_log_2026_08_08_055037.txt#FD-')]
    ok('corrected_father_log_42_entries', len(corrected)==42, len(corrected))
    ok('old_053534_not_primary', 'SUPERSEDED_BY_TIME_RETENTION_CORRECTION / AUDIT_ONLY' in (root/'admin/SOURCE_SUPERSESSION_LEDGER.md').read_text(encoding='utf-8'))

    # static/harness separation
    live=json.loads((root/'tests/FIVE_CANON_COLD_START_LIVE_TRACE.json').read_text(encoding='utf-8'))
    ok('live_acceptance_pending_not_faked',
       live.get('LIVE_HOST_ACCEPTANCE')=='PENDING' and live.get('RELEASE_ACCEPTANCE')=='BLOCKED'
       and 'multi_turn_live_pass' in live.get('NOT_CLAIMED',[]), live.get('STATUS'))
    neg=json.loads((root/'tests/NEGATIVE_SUBSTITUTION_NO_LATE_REPAIR_RESULTS.json').read_text(encoding='utf-8'))
    ok('negative_contract_tests', neg.get('STATUS')=='PASS' and len(neg.get('CASES',[]))>=8 and all(c['observed'].startswith('FAIL') for c in neg['CASES']), len(neg.get('CASES',[])))

    # actual current build turn only, not live cold-start
    tr=json.loads((root/'tests/CURRENT_BUILD_TURN_ACTUAL_TRACE.json').read_text(encoding='utf-8'))
    ok('current_build_turn_actual_trace',
       tr.get('SUCCESSFUL_CAPTURE_ACTION_INDEX')==1 and tr.get('CAPTURE_ATTEMPTS')>=1
       and tr.get('INTERVENING_ACTION_BEFORE_SUCCESS')=='NONE' and tr.get('INGRESS_ORDER_VALID') is True
       and tr.get('LIVE_COLD_START_ACCEPTANCE') is False, tr.get('TRACE_DIGEST'))

    # static consecutive harness with actual Python provider calls
    g=Gate(True,True); positives=[]
    kinds=['short_chat','image_turn','file_turn','web_turn','boot_turn','artifact_turn','post_correction_1','post_correction_2','multiple_turn_1','multiple_turn_2']
    for k in kinds:
        r=g.turn(); positives.append({'kind':k,**r})
    retry=g.turn(fail_first=True); positives.append({'kind':'environment_failure_immediate_retry',**retry})
    negatives=[
      g.turn(pre_action='commentary'),
      Gate(False,True).turn(),
      Gate(True,False).turn(),
      g.turn(unbound=True)
    ]
    harness_pass=all(x['result']=='PASS' for x in positives) and all(x['result'].startswith('FAIL') for x in negatives)
    ok('static_runtime_harness',harness_pass,{'positive':len(positives),'negative':len(negatives)})

    # migration lineage still points to immutable rev0.305
    mig=[json.loads(x) for x in (root/'admin/CURRENT_TO_RC3_MIGRATION_LEDGER.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
    base_entries=[x for x in mig if str(x.get('ENTRY_ID','')).startswith('MIG-') and x.get('LINEAGE_PACKAGE_SHA256')]
    ok('migration_rev305_lineage', len(base_entries)>=2000 and all(x.get('LINEAGE_PACKAGE_SHA256')==BASELINE_SHA for x in base_entries), len(base_entries))

    # README Japanese user-facing prose
    readme=(root/'README.md').read_text(encoding='utf-8')
    jp=sum(1 for ch in readme if '\u3040'<=ch<='\u30ff' or '\u4e00'<=ch<='\u9fff')
    ok('readme_japanese_primary', jp>120, jp)

    # source actual hashes
    expected_f='cae1ae92a431c3b9bdb0df5f68d629fb57089129fad14e040471389e5171431b'
    expected_d='e8e63cee106733e35b2b44d50a5a46617a45f55752a925398e3f688b24e982f3'
    ok('primary_source_actual_hashes',
       sha(root/'source/PEOS_father_session_log_2026_08_08_055037.txt')==expected_f and
       sha(root/'source/PEOS_rev0_306_RC3_BUILD_DIRECTIVE_2026_08_08_055037.txt')==expected_d)

    # Evidence limitation honest
    ev=(root/'evidence/PEOS_EVIDENCE.txt').read_text(encoding='utf-8')
    ok('mother_source_hash_limitation_disclosed',
       'RAW_BYTES_MOUNTED_IN_CURRENT_BUILD: FALSE' in ev and 'INDEPENDENT_HASH_RECOMPUTATION: NOT_PERFORMED' in ev)

    # manifest optional in precommit, required final
    if check_manifest:
        meta,files=manifest_entries(root/'PACKAGE_MANIFEST.txt')
        ok('manifest_metadata',
           meta.get('VERSION')==RC and meta.get('OPERATIVE_CURRENT')==OPERATIVE
           and meta.get('BASELINE_SHA256')==BASELINE_SHA
           and meta.get('BASELINE_SIDECAR_FILE_SHA256')==BASELINE_SIDECAR_SHA
           and meta.get('LIVE_HOST_ACCEPTANCE')=='PENDING'
           and meta.get('RELEASE_ACCEPTANCE')=='BLOCKED')
        bad=[]
        for rel,rec in files.items():
            p=root/rel
            if not p.is_file() or sha(p)!=rec['sha256'] or p.stat().st_size!=rec['bytes']:
                bad.append(rel)
        expected=set(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='PACKAGE_MANIFEST.txt')
        ok('manifest_hashes',not bad and set(files)==expected,{'bad':bad,'missing':sorted(expected-set(files)),'extra':sorted(set(files)-expected)})
    return checks,details,{'harness_positive':positives,'harness_negative':negatives}

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('root',nargs='?',default='.')
    ap.add_argument('--manifest',action='store_true')
    a=ap.parse_args()
    c,d,h=run(Path(a.root),a.manifest)
    out={'candidate':RC,'checks':c,'details':d,'harness':h,'STATIC_PASS':all(c.values()),'LIVE_HOST_ACCEPTANCE':'PENDING','RELEASE_ACCEPTANCE':'BLOCKED'}
    print(json.dumps(out,ensure_ascii=False,indent=2))
    sys.exit(0 if all(c.values()) else 1)
