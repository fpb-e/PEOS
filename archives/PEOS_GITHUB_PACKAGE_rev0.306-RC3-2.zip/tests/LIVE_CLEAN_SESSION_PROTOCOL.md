# Live clean-session acceptance protocol — rev0.306-RC3

このprotocolは外部父レビューで実施する。package生成turn内のsimulationで代用しない。

各turnについてhost transcriptから以下を採取する。

- user turn identifier
- event ordinal 1
- action index 1
- actual Python tool invocation
- provider expression
- returned JST value
- commentary/context/file/web/shell/artifact/MAGI/outputの先行件数=0
- displayed receiptとtraceの一致

連続scenarioを全件実user turnで実施する。1件でも欠損したらrelease FAIL。父の明示acceptance前にoperativeへ昇格しない。
