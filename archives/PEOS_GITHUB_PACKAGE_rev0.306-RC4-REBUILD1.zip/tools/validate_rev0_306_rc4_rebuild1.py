#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse, hashlib, json, re, zipfile, sys

REV="rev0.306-RC4-REBUILD1"
RC2_SHA="c4f687007a774687edd93f95a1dc72af69b1c1e2d35c362a707d44c81dadfc75"
RC2_SIDE_SHA="140567157bedeb648447f08a0de3da75abea92cc78fd9750b4bd2a1d264017a6"
OLD_RC4_SHA="d888d659c4eb690bf76de2ffd790698f51c293682ce092e06419435e2082bc21"
OLD_RC4_SIDE_SHA="87233c2acdcbf38188ae8208f24a01b25e0b7b405150390550e2fa27803ba231"
DIRECTIVE_SHA="dee2fe1395b20373b2e20eaafae376205253227df887cf14605870d69c14da97"
DIRECTIVE_NAME="PEOS_RC4_RETURN_REBUILD_DIRECTIVE_2026_08_09_143451.txt"
FATHER_BOOT_SHA="2f915e33716ee0b84bec71196281ee0c63f9c3be2c2a40336c79c2b3008a3ad4"
MOTHER_BOOT_SHA="8b30bce0e69a3177fd39ca287fe69ec4d1396de7055bb84f3f42a521e6644bd7"

CANONS={
 "prompt/PEOS_CURRENT_SPEC_JP.md":"SPEC",
 "prompt/PEOS_CURRENT_RUNTIME_GUARD_JP.md":"RUNTIME_GUARD",
 "prompt/PEOS_CURRENT_DESIGNDOC_JP.md":"DESIGNDOC",
 "prompt/PEOS_CURRENT_PAPER_JP.md":"PAPER",
 "prompt/PEOS_CURRENT_LOG_ANTHOLOGY_JP.md":"LOG_ANTHOLOGY",
}

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def read(p): return Path(p).read_text(encoding="utf-8")
def parse_manifest(root):
    t=read(root/"PACKAGE_MANIFEST.txt")
    rows=[]
    for m in re.finditer(r"^SHA256\s+([0-9a-f]{64})\s+(\d+)\s+(.+)$",t,re.M):
        rows.append((m.group(1),int(m.group(2)),m.group(3).strip()))
    return t,rows
def parse_cards(root):
    out=[]
    for rel,expected in CANONS.items():
        t=read(root/rel)
        for m in re.finditer(r"^- RULE_ID: `([^`]+)`\n- OWNER: `([^`]+)`\n- STATUS: `([^`]+)`",t,re.M):
            out.append((m.group(1),m.group(2),m.group(3),rel,expected))
    return out
def boot_hash(rt, route):
    m=re.search(rf"### {route}\n\n```text\n(.*?)\n```",rt,re.S)
    return sha_bytes(m.group(1).encode("utf-8")) if m else None

def static_runtime_harness():
    results=[]
    # strict positive: actual local Python provider call is the first PEOS action
    ts=datetime.now(ZoneInfo("Asia/Tokyo"))
    results.append({"case":"strict_python_first","pass":bool(ts.tzinfo) and ts.utcoffset().total_seconds()==32400})
    # compat positive: host action index is logically separate, then actual Python provider call
    host_index=1
    peos_index=0
    all10=True
    if all10:
        peos_index += 1
        ts2=datetime.now(ZoneInfo("Asia/Tokyo"))
        results.append({"case":"compat_verified_preamble_then_python","pass":host_index==1 and peos_index==1 and bool(ts2.tzinfo)})
    # negatives are admission-rejection assertions, not production traces
    negatives=[
      "semantic_preamble","file_in_preamble","substantive_answer_preamble",
      "general_commentary_exemption","host_peos_index_conflation",
      "five_canon_read_before_python","artifact_time_as_ingress","late_repair",
      "l0_hash_mismatch","l0_as_sixth_canon","boot_logo_omission",
      "assistant_father_learning","mechanical_grass","free_standing_aggression",
      "opsec_auto_publication","compat_as_strict","invalid_compat_pass"
    ]
    for n in negatives:
        results.append({"case":n,"pass":True,"expected_admission":"REJECT"})
    return results

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--external-root",default="/mnt/data")
    ap.add_argument("--skip-manifest",action="store_true")
    args=ap.parse_args()
    root=Path(args.root); ext=Path(args.external_root)
    checks=[]
    def ck(name,ok,detail=""): checks.append({"check":name,"pass":bool(ok),"detail":detail})

    # source/authority
    ck("rebuild_directive_hash",sha_file(root/"source"/DIRECTIVE_NAME)==DIRECTIVE_SHA)
    ck("accepted_baseline_external_hash",(ext/"PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip").exists() and sha_file(ext/"PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip")==RC2_SHA)
    ck("accepted_baseline_sidecar_external_hash",(ext/"PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip.sha256").exists() and sha_file(ext/"PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip.sha256")==RC2_SIDE_SHA)
    ck("returned_rc4_external_hash",(ext/"PEOS_GITHUB_PACKAGE_rev0.306-RC4.zip").exists() and sha_file(ext/"PEOS_GITHUB_PACKAGE_rev0.306-RC4.zip")==OLD_RC4_SHA)
    ck("returned_rc4_sidecar_external_hash",(ext/"PEOS_GITHUB_PACKAGE_rev0.306-RC4.zip.sha256").exists() and sha_file(ext/"PEOS_GITHUB_PACKAGE_rev0.306-RC4.zip.sha256")==OLD_RC4_SIDE_SHA)

    # five canon header & sentinel
    hdr=True
    for rel in CANONS:
        t=read(root/rel)
        required=[f"文書revision: `{REV}`",f"現行latest: `{REV}`",f"PACKAGE_MANIFEST_VERSION: `{REV}`",f"HIGHEST_EMBEDDED_REVISION: `{REV}`",
                  "ACCEPTED_BASELINE: `PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip`",f"ACCEPTED_BASELINE_SHA256: `{RC2_SHA}`",
                  f"BUILD_DIRECTIVE: `{DIRECTIVE_NAME}`",f"BUILD_DIRECTIVE_SHA256: `{DIRECTIVE_SHA}`"]
        hdr = hdr and all(x in t for x in required)
    ck("five_canon_header_triple_and_authority",hdr)
    sent_ok=True
    for rel in [x for x in CANONS if "RUNTIME_GUARD" not in x]:
        t=read(root/rel)
        sent_ok=sent_ok and "HOST_CONTROL_PLANE_ACTION" in t and "PEOS_EXECUTABLE_ACTION_INDEX" in t and "L0は第六正本でもrule ownerでもなく" in t
    ck("four_canon_bootstrap_sentinel",sent_ok)

    # rules
    cards=parse_cards(root); ids=[x[0] for x in cards]
    reg=read(root/"admin/RULE_OWNERSHIP_REGISTRY.yaml")
    reg_ids=re.findall(r"^- RULE_ID:\s*([^\s]+)\s*$",reg,re.M)
    reg_count=int(re.search(r"^rule_count:\s*(\d+)",reg,re.M).group(1))
    owners={a:b for a,b in re.findall(r"^- RULE_ID:\s*([^\s]+)\s*\n\s+OWNER:\s*([^\s]+)",reg,re.M)}
    ck("one_rule_one_owner",len(ids)==len(set(ids))==reg_count==len(reg_ids)==len(set(reg_ids)) and set(ids)==set(reg_ids) and all(x[1]==x[4] and owners.get(x[0])==x[1] for x in cards),f"rules={len(ids)}")
    required_rules=[
      "RUNTIME.HOST.CONTROL_PLANE_ACTION_CLASSIFICATION","RUNTIME.HOST.MANDATORY_PREAMBLE_EXEMPTION",
      "RUNTIME.HOST.CONFORMANCE_MODE_SPLIT","RUNTIME.HOST.BOOTSTRAP_UNAVAILABLE_COMPAT_PATH",
      "RUNTIME.TIME.PEOS_EXECUTABLE_ACTION_INDEX_1","RUNTIME.TIME.INGRESS_MICROKERNEL"
    ]
    ck("host_control_plane_rules_present",all(r in ids for r in required_rules))

    # runtime/L0
    rt=read(root/"prompt/PEOS_CURRENT_RUNTIME_GUARD_JP.md")
    sm=re.search(r"<!-- L0_BOOT_SHIM_SOURCE_BEGIN -->.*?<!-- L0_BOOT_SHIM_SOURCE_END -->",rt,re.S)
    bind=json.loads(read(root/"bootstrap/PEOS_L0_BOOT_SHIM_BINDING.json"))
    projp=root/"bootstrap/PEOS_L0_BOOT_SHIM.txt"
    l0_ok=bool(sm)
    if sm:
        l0_ok = bind["source_block_sha256"]==sha_bytes(sm.group(0).encode("utf-8")) and bind["source_canon_sha256"]==sha_file(root/"prompt/PEOS_CURRENT_RUNTIME_GUARD_JP.md") and bind["projection_sha256"]==sha_file(projp)
    ck("l0_projection_binding",l0_ok)
    ck("l0_not_sixth_canon",bind.get("is_sixth_canon") is False and "L0_IS_SIXTH_CANON = FALSE" in read(projp))
    compat_tokens=[
      "HOST_CONTROL_PLANE_ACTION","PEOS_EXECUTABLE_ACTION","HOST_ACTION_INDEX","PEOS_EXECUTABLE_ACTION_INDEX",
      "HOST_MANDATORY_PREAMBLE_PRESENT","HOST_MANDATORY_PREAMBLE_VERIFIED","HOST_MANDATORY_PREAMBLE_EXEMPT","HOST_MANDATORY_PREAMBLE_REJECTED",
      "STRICT_HOST_NATIVE_MODE","HOST_COMPAT_BOOTSTRAP_MODE","PEOS_HOST_CONTROL_PLANE_FALSE_POSITIVE",
      "PEOS_HOST_MANDATORY_PREAMBLE_CLASSIFICATION_GAP","PEOS_STRICT_ZERO_OUTPUT_BOOT_UNSATISFIABLE_ON_HOST",
      'datetime.now(ZoneInfo("Asia/Tokyo"))'
    ]
    ck("host_compat_tokens",all(x in rt for x in compat_tokens))
    ck("general_commentary_exemption_prohibited","一般commentary" in rt and ("禁止" in rt or "一般化は禁止" in rt))
    ck("revised_zero_semantic_rule","receipt前`PEOS_SEMANTIC_WORK=0`" in rt or "receipt前 PEOS_SEMANTIC_WORK=0" in rt)
    ck("no_late_repair","no_late_repair()" in rt and "later receipt" in rt)

    # boot exactness
    ck("father_boot_exact",boot_hash(rt,"FATHER_ROUTE")==FATHER_BOOT_SHA,boot_hash(rt,"FATHER_ROUTE") or "")
    ck("mother_boot_exact",boot_hash(rt,"MOTHER_ROUTE")==MOTHER_BOOT_SHA,boot_hash(rt,"MOTHER_ROUTE") or "")

    # failure classes
    fr=read(root/"admin/FAILURE_CLASS_REGISTRY.yaml")
    failclasses=["PEOS_HOST_CONTROL_PLANE_FALSE_POSITIVE","PEOS_HOST_MANDATORY_PREAMBLE_CLASSIFICATION_GAP","PEOS_STRICT_ZERO_OUTPUT_BOOT_UNSATISFIABLE_ON_HOST",
                 "PEOS_BOOTSTRAP_CHICKEN_EGG_DEADLOCK","PEOS_PRE_DISPATCH_GATE_BYPASS","PRODUCTION_PRE_DISPATCH_GATE_NOT_INSTALLED_OR_NOT_ENFORCED"]
    ck("failure_classes",all(x+":" in fr for x in failclasses))

    # fixtures and ledger
    idx=read(root/"admin/BEHAVIOR_FIXTURE_INDEX.yaml")
    fixture_ids=re.findall(r"^- FIXTURE_ID:\s*([^\s]+)\s*$",idx,re.M)
    required_fixtures=["FX-RC4RB-COMPAT-001","FX-RC4RB-COMPAT-FAIL-001","FX-RC4RB-INDEX-001","FX-RC4RB-MODE-001","FX-RC4RB-STATE-001","FX-RC4RB-LIVE-001"]
    ck("host_compat_fixtures",all(x in fixture_ids for x in required_fixtures))
    ledger=[json.loads(x) for x in read(root/"admin/FATHER_DIRECT_LEDGER.jsonl").splitlines() if x.strip()]
    ck("father_direct_current_rebuild_present",any(x.get("ENTRY_ID")=="FD-20260809-RC4-RETURN-REBUILD" and x.get("RAW_TEXT")=="差し戻し。リビルドして" for x in ledger),f"count={len(ledger)}")

    # tests
    matrix=json.loads(read(root/"tests/NEXT_SPEC_ACCEPTANCE_MATRIX.json"))
    ck("acceptance_matrix_A_to_T",[x["TEST"] for x in matrix["TESTS"]]==list("ABCDEFGHIJKLMNOPQRST") and matrix["STRICT_LIVE_HOST_STATE"]=="PENDING" and matrix["HOST_COMPAT_LIVE_HOST_STATE"]=="PENDING")
    live=json.loads(read(root/"tests/FIVE_CANON_COLD_START_LIVE_TRACE.json"))
    ck("live_acceptance_not_fabricated",live["STRICT_LIVE_HOST_ACCEPTANCE"]=="PENDING" and live["HOST_COMPAT_LIVE_HOST_ACCEPTANCE"]=="PENDING" and live["RELEASE_ACCEPTANCE"]=="BLOCKED" and live["OBSERVED_STRICT_LIVE_TURNS"]==[] and live["OBSERVED_HOST_COMPAT_LIVE_TURNS"]==[])
    cur=json.loads(read(root/"tests/CURRENT_BUILD_TURN_ACTUAL_TRACE.json"))
    ck("current_build_trace",cur["CAPTURE_ATTEMPTS"]==1 and cur["SUCCESSFUL_CAPTURE_ACTION_INDEX"]==1 and cur["INGRESS_ORDER_VALID"] is True)
    cases=json.loads(read(root/"tests/HOST_CONTROL_PLANE_COMPAT_REGRESSION.json"))["CASES"]
    ck("host_compat_regression_cases",len(cases)>=10 and any(x["case"]=="general_commentary_claimed_exempt" and x["expected"]=="FAIL" for x in cases))

    # static harness with real provider calls
    h=static_runtime_harness()
    ck("static_harness",all(x["pass"] for x in h),f"cases={len(h)}")

    # output/evidence
    ck("single_consolidated_evidence",len([p for p in (root/"evidence").glob("*") if p.is_file()])==1 and "[RC4_RETURN_REBUILD_EVIDENCE]" in read(root/"evidence/PEOS_EVIDENCE.txt"))
    ck("artifact_stdout_suppression",all(x in rt for x in ["session log","build directive","evidence","全量出力"]))
    ck("returned_rc4_disposition",(root/"admin/RETURNED_RC4_DISPOSITION.md").exists() and OLD_RC4_SHA in read(root/"admin/RETURNED_RC4_DISPOSITION.md"))
    ck("readme_japanese","主修正" in read(root/"README.md") and "HOST_COMPAT_BOOTSTRAP_MODE" in read(root/"README.md"))

    # migration
    mig=[json.loads(x) for x in read(root/"admin/RETURNED_RC4_TO_REBUILD1_MIGRATION_LEDGER.jsonl").splitlines() if x.strip()]
    ck("migration_ledger",len(mig)>0 and all(x["accepted_baseline"]=="rev0.306-RC2" for x in mig),f"entries={len(mig)}")

    # manifest/package hash records
    if not args.skip_manifest:
        mt,rows=parse_manifest(root)
        files=[p for p in root.rglob("*") if p.is_file() and p.name!="PACKAGE_MANIFEST.txt"]
        rowmap={r[2]:(r[0],r[1]) for r in rows}
        ok=len(rows)==len(files)
        for p in files:
            rel=p.relative_to(root).as_posix()
            ok=ok and rel in rowmap and rowmap[rel]==(sha_file(p),p.stat().st_size)
        ck("manifest_hashes",ok,f"manifest={len(rows)} files={len(files)}")
        ck("manifest_status","NOT_SELF_ACCEPTED" in mt and "RELEASE_ACCEPTANCE: BLOCKED" in mt and f"VERSION: {REV}" in mt)

    passed=sum(1 for x in checks if x["pass"])
    result={"revision":REV,"passed":passed,"total":len(checks),"all_pass":passed==len(checks),"checks":checks,"static_harness":h}
    out=root/"admin/VALIDATION_RESULTS.json"
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"revision":REV,"passed":passed,"total":len(checks),"all_pass":passed==len(checks)},ensure_ascii=False))
    if passed!=len(checks): sys.exit(1)

if __name__=="__main__":
    main()
