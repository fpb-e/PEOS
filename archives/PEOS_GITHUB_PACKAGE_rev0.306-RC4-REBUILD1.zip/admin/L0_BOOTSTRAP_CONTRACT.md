# L0 BOOTSTRAP CONTRACT — rev0.306-RC4-REBUILD1

L0はRUNTIME_GUARD authoritative source blockから生成されるnon-authoritative projectionであり、第六正本ではない。

## mode
- `STRICT_HOST_NATIVE_MODE`: true pre-dispatch hookでPython前にmodel/PEOS action不要。
- `HOST_COMPAT_BOOTSTRAP_MODE`: platform-mandatory control preambleだけが先行可能。

compatのpreambleはRUNTIME_GUARD Section -2の10条件を全件満たす必要がある。
一般commentary、user要約、判断、tool/contextアクセスをexemptしない。

## action index
- host control event: `HOST_ACTION_INDEX`
- PEOS action: `PEOS_EXECUTABLE_ACTION_INDEX`
- first PEOS executable action: actual `datetime.now(ZoneInfo("Asia/Tokyo"))`

Source hash bindingは`bootstrap/PEOS_L0_BOOT_SHIM_BINDING.json`で管理する。
