# HOST COMPAT BOOTSTRAP CONTRACT — rev0.306-RC4-REBUILD1

`HOST_MANDATORY_PREAMBLE_EXEMPT=TRUE`は以下を全件満たす場合だけ許可する。

1. host/platform mandatoryでtrace識別可能
2. user semantic解析なし
3. user内容の評価・要約・判断・推論なし
4. file/Library/Personal Context/web/shell/artifact/MAGI/five-canon semantic readなし
5. father-style/OPSEC/evidence/application logicなし
6. boot success/failure最終宣言なし
7. substantive answerなし
8. fixed/minimal control text
9. ingress開始以上の情報を極力含めない
10. host actionとして別index/entityへ記録

一つでも欠ければ`HOST_MANDATORY_PREAMBLE_REJECTED=TRUE`。
