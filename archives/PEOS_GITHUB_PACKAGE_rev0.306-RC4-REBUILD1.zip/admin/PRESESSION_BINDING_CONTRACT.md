# PRESESSION BINDING CONTRACT — rev0.306-RC4-REBUILD1

## strict-native
`L0_INTEGRITY_VALID=TRUE`、`L0_BOOTSTRAP_BOUND=TRUE`、`HOST_PRE_DISPATCH_HOOK_INSTALLED=TRUE`、
`FIRST_USER_TURN_ARMED=TRUE`をpre-session host evidenceで確立する。

## host-compatible
true native hookが利用できないhostでは、L0/control classifierとsemantic lockを準備する。
user turnでmandatory host preambleが不可避なら10条件を全件検証し、verified/exempt後も
`SEMANTIC_WORK_AUTHORIZED=FALSE`を維持する。
最初のPEOS executable actionはactual Python JST capture。

strict hook欠如だけで`HOST_BOOTSTRAP_UNAVAILABLE`を確定しない。
compatも成立しない場合だけfail-closedする。
