# PRODUCTION HOST GATE CONTRACT — rev0.306-RC4-REBUILD1

1. host capabilityを`STRICT_HOST_NATIVE_MODE`または`HOST_COMPAT_BOOTSTRAP_MODE`として型判定する。
2. strict hookがないだけでは`HOST_BOOTSTRAP_UNAVAILABLE`を確定しない。
3. compat preambleは10条件の全件trace検証が必要。
4. verified host control eventは`HOST_ACTION_INDEX`だけへ記録する。
5. `PEOS_EXECUTABLE_ACTION_INDEX=1`はactual `datetime.now(ZoneInfo("Asia/Tokyo"))`。
6. receipt前の`PEOS_SEMANTIC_WORK`は0件。
7. preambleにuser prompt要約/判断/推論、file/context/web/MAGI/artifact等が含まれればFAIL。
8. compat PASSをstrict PASSと表示しない。
9. later Python、artifact time、later turn receiptによるrepairは禁止。
10. static validator/harness PASSはlive trace PASSではない。
