# LIVE CLEAN SESSION PROTOCOL — rev0.306-RC4

本試験はstatic validator/harnessとは別で、実hostのclean sessionで実施する。

Pre-session:
1. `bootstrap/PEOS_L0_BOOT_SHIM.txt`をhostへbind。
2. source revision/hash integrityを確認。
3. L0を第六正本・semantic authorityとして扱わない。
4. five canonをsemanticに読まない。

各user turn:
1. actual `datetime.now(ZoneInfo("Asia/Tokyo"))` tool eventがfirst executable action。
2. receipt前non-time actionは0。
3. receipt検証後にfive canon load / validate / compile。
4. その後のみsemantic dispatch。

必須turn:
- first short chat
- image
- file
- web
- boot
- artifact generation
- correction直後
- multiple consecutive turns

一turnでも欠損すれば`LIVE_HOST_ACCEPTANCE=FAIL`。percentage/majority/self-report/late repairは禁止。
