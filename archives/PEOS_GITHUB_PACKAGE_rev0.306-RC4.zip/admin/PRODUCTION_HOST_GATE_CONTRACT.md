# PRODUCTION HOST GATE CONTRACT — rev0.306-RC4

本contractはhostがPEOS strict conformanceを提供するための境界を定義する。

1. pre-sessionでbindするのは`bootstrap/PEOS_L0_BOOT_SHIM.txt`のみ。
2. L0はnon-authoritative projectionであり、第六正本ではない。
3. user turn到着時、semantic dispatchより前のaction index 1はactual `datetime.now(ZoneInfo("Asia/Tokyo"))`のみ。
4. actual tool event / turn id / event id / provider / returned value / action index / trace digest / attempts / intervening actionを検証する。
5. receipt成功後にのみfive canonをload/validate/compileする。
6. receipt前のcommentary、context、file、web、artifact、MAGI、boot completionは0件でなければならない。
7. host hook、tool、trace、action-index-1保証のいずれかがない場合は`HOST_BOOTSTRAP_UNAVAILABLE`でfail-closed。
8. late Python、artifact time、later turn receiptによる修復は禁止。
9. static validator/harness PASSはlive production trace PASSではない。
