# L0 BOOTSTRAP CONTRACT — rev0.306-RC4

L0はRUNTIME_GUARDのauthoritative source blockから生成されるhost loader projectionであり、canonではない。

- Source canon: `prompt/PEOS_CURRENT_RUNTIME_GUARD_JP.md`
- Source canon SHA-256: `d61eb9c85d6347aa0d2d978ee06be052fa07afcdd0b6e8c97afe82b7bd1efdff`
- Source block SHA-256: `42c17f4bd236ea1dc06303d08fe09b54d679b9fb5b301046d7f2aa294950ac49`
- Projection SHA-256: `64b683f5d87b660555af30eb8d905bdd667071803cc146ebe89eb54e9ca78ec2`
- Rule owner: `RUNTIME_GUARD`
- Semantic rule ownership: `NONE`
- Father style / MAGI / OPSEC / evidence / coordinate logic ownership: `PROHIBITED`

HostがL0をprebindできない場合、strict PEOS boot successを宣言してはならない。
