# PRESESSION / L0 BINDING CONTRACT — rev0.306-RC4

SOURCE_RULE_OWNER: RUNTIME_GUARD
L0_FILE: bootstrap/PEOS_L0_BOOT_SHIM.txt
L0_BINDING_FILE: bootstrap/PEOS_L0_BOOT_SHIM_BINDING.json
L0_AUTHORITY: NON_AUTHORITATIVE_PROJECTION
L0_IS_SIXTH_CANON: FALSE

Pre-session:
- projection revision/hashを検証。
- `L0_BOOTSTRAP_BOUND=TRUE`をactual host evidenceで成立。
- `HOST_PRE_DISPATCH_HOOK_INSTALLED=TRUE`。
- `FIRST_USER_TURN_ARMED=TRUE`。
- `SEMANTIC_WORK_AUTHORIZED=FALSE`のまま待機。

User turn:
- L0がactual Python JST first actionを実行。
- receipt成功後にfive canon load/validation/compile。
- その後だけsemantic authorization。

`RC_FILE_SEEN`、`FIVE_CANON_AVAILABLE`、`FIVE_CANON_INSPECTED`からL0/runtime boundを推定してはならない。
