# PEOS NEXT SPEC CHARTER — rev0.306-RC4

## Release fence
- TARGET: `rev0.306-RC4`
- STATUS: `RELEASE_CANDIDATE / NOT_ACCEPTED / NOT_SELF_ACCEPTED`
- PROJECT_LEVEL_CURRENT_REFERENCE: `rev0.306-RC3`
- ACCEPTED_BASELINE: `PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip`
- ACCEPTED_BASELINE_SHA256: `c4f687007a774687edd93f95a1dc72af69b1c1e2d35c362a707d44c81dadfc75`

## Primary changes
1. `PEOS_BOOTSTRAP_CHICKEN_EGG_DEADLOCK`をL0 bootstrapで解消する。
2. L0はRUNTIME_GUARD authoritative blockのnon-authoritative projectionであり、第六正本ではない。
3. first/per-turn actual Python JST receipt前のsemantic actionを全面禁止する。
4. BOOT_CANON exact literalをimmutableとして扱う。
5. father-direct source learningをbehavior structureまで拡張する。
6. mother regression logをingress negative fixtureとして保持する。
7. session log/directive/evidence本文のchat/stdout全量出力を禁止する。
8. live clean-session host acceptanceとstatic validationを分離する。

## Acceptance
static/package PASSは必要条件であり、live host PASSやfather acceptanceの代替ではない。
