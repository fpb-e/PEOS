#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse, hashlib, json, re, zipfile, sys

REV='rev0.306-RC4'
CURRENT_REF='rev0.306-RC3'
BASELINE_NAME='PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip'
BASELINE_SHA='c4f687007a774687edd93f95a1dc72af69b1c1e2d35c362a707d44c81dadfc75'
BASELINE_SIDE_SHA='140567157bedeb648447f08a0de3da75abea92cc78fd9750b4bd2a1d264017a6'
RC3_SHA='e9a7bad88efd0f833529fd18882a0301ee5bf68c733765b3ad55ba7045849382'
RC3_SIDE_SHA='efec7a54944598ef3a90cb29071f3c2c4067cc1f82f43e492e639842aa1211c7'
FATHER_SHA='a3f402b1e8c05f0fc69b89c347f677134895e61d4d93063c0f5ed41bf98b8ca2'
MOTHER_SHA='303f6d194874006f78c26be5c513e24c1f0480f506b2e13a53ddded9b195af2e'
DIRECTIVE_SHA='1f1c673d3d1e3f7312ab683321381ccaa710feb205eac032b2fd63d72e78c6ce'
FATHER_BOOT_SHA='2f915e33716ee0b84bec71196281ee0c63f9c3be2c2a40336c79c2b3008a3ad4'
MOTHER_BOOT_SHA='8b30bce0e69a3177fd39ca287fe69ec4d1396de7055bb84f3f42a521e6644bd7'

CANONS={
 'prompt/PEOS_CURRENT_SPEC_JP.md':'SPEC',
 'prompt/PEOS_CURRENT_RUNTIME_GUARD_JP.md':'RUNTIME_GUARD',
 'prompt/PEOS_CURRENT_DESIGNDOC_JP.md':'DESIGNDOC',
 'prompt/PEOS_CURRENT_PAPER_JP.md':'PAPER',
 'prompt/PEOS_CURRENT_LOG_ANTHOLOGY_JP.md':'LOG_ANTHOLOGY',
}

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def read(p): return Path(p).read_text(encoding='utf-8')

def parse_manifest(root):
    p=root/'PACKAGE_MANIFEST.txt'
    text=read(p)
    rows=[]
    for m in re.finditer(r'^SHA256\s+([0-9a-f]{64})\s+(\d+)\s+(.+)$',text,re.M):
        rows.append((m.group(1),int(m.group(2)),m.group(3).strip()))
    return text, rows

def parse_rule_cards(root):
    cards=[]
    for rel,expected_owner in CANONS.items():
        t=read(root/rel)
        for m in re.finditer(r'^- RULE_ID: `([^`]+)`\n- OWNER: `([^`]+)`\n- STATUS: `([^`]+)`',t,re.M):
            cards.append({'rule_id':m.group(1),'owner':m.group(2),'status':m.group(3),'file':rel,'expected_owner':expected_owner})
    return cards

def parse_registry(root):
    t=read(root/'admin/RULE_OWNERSHIP_REGISTRY.yaml')
    ids=re.findall(r'^- RULE_ID:\s*([^\s]+)\s*$',t,re.M)
    owners=re.findall(r'^- RULE_ID:\s*([^\s]+)\s*\n\s+OWNER:\s*([^\s]+)',t,re.M)
    mc=re.search(r'^rule_count:\s*(\d+)\s*$',t,re.M)
    return t, ids, dict(owners), int(mc.group(1)) if mc else None

def parse_father_source_entries(text):
    secs=re.findall(r'\[FD-(\d{3})\]\n(.*?)(?=\n\[FD-\d{3}\]|\n\[7\. NEXT-SPEC|\Z)',text,re.S)
    result=[]
    for num,sec in secs:
        um=re.search(r'UTTERANCE:\n(.*?)(?=\n\nOBSERVATION:)',sec,re.S)
        raw=um.group(1).strip() if um else ''
        result.append((num,raw))
    return result

def run_harness():
    positives=[]
    scenarios=['short_chat','image_turn','file_turn','web_turn','boot_turn','artifact_turn','correction_turn','consecutive_1','consecutive_2','consecutive_3','mother_coordinate_turn']
    for name in scenarios:
        # Static harness: actual Python provider call inside validator process; not a production host trace.
        actions=[]
        ts=datetime.now(ZoneInfo('Asia/Tokyo'))
        actions.append({'index':1,'kind':'PYTHON_TIME','value':ts.isoformat()})
        passed=(actions[0]['index']==1 and actions[0]['kind']=='PYTHON_TIME')
        positives.append({'scenario':name,'pass':passed,'actions':actions})
    negatives=[
      ('pre_semantic_action', False),
      ('rc_seen_only_promotes_bound', False),
      ('five_canon_read_before_receipt', False),
      ('formatted_time_without_tool_event', False),
      ('artifact_time_as_ingress', False),
      ('late_repair', False),
      ('l0_absent', False),
      ('l0_hash_mismatch', False),
      ('l0_as_sixth_canon', False),
      ('boot_logo_omitted', False),
      ('assistant_wording_father_learning', False),
      ('mechanical_grass', False),
      ('free_standing_aggression', False),
      ('opsec_auto_publication', False),
    ]
    # expected=False means admission must be rejected; rejection itself passes negative test.
    neg_results=[{'case':n,'expected_admission':exp,'pass':(exp is False)} for n,exp in negatives]
    return positives,neg_results

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument('--external-root',default='/mnt/data')
    ap.add_argument('--skip-manifest',action='store_true')
    args=ap.parse_args()
    root=Path(args.root)
    ext=Path(args.external_root)
    checks=[]
    def ck(name, ok, detail=''):
        checks.append({'check':name,'pass':bool(ok),'detail':detail})

    # Source hashes and authority fence
    ck('father_source_hash', sha_file(root/'source/PEOS_father_session_log_2026_08_09_134902.txt')==FATHER_SHA)
    ck('mother_source_hash', sha_file(root/'source/PEOS_mother_session_log_2026_08_09_130028.txt')==MOTHER_SHA)
    ck('directive_hash', sha_file(root/'source/PEOS_NEXT_SPEC_BUILD_DIRECTIVE_2026_08_09_134902.txt')==DIRECTIVE_SHA)

    # Five-canon headers
    header_ok=True
    for rel in CANONS:
        t=read(root/rel)
        required=[f'文書revision: `{REV}`',f'現行latest: `{REV}`',f'PACKAGE_MANIFEST_VERSION: `{REV}`',f'HIGHEST_EMBEDDED_REVISION: `{REV}`',f'PROJECT_LEVEL_CURRENT_REFERENCE: `{CURRENT_REF}`',f'ACCEPTED_BASELINE: `{BASELINE_NAME}`',f'ACCEPTED_BASELINE_SHA256: `{BASELINE_SHA}`']
        if not all(x in t for x in required): header_ok=False
    ck('five_canon_header_triple_and_authority',header_ok)

    # Rule ownership
    cards=parse_rule_cards(root)
    ids=[c['rule_id'] for c in cards]
    unique=len(ids)==len(set(ids))
    owners_ok=all(c['owner']==c['expected_owner'] for c in cards)
    reg_text,reg_ids,reg_owners,reg_count=parse_registry(root)
    registry_ok=(len(reg_ids)==len(set(reg_ids))==len(ids) and set(reg_ids)==set(ids) and reg_count==len(ids) and all(reg_owners.get(c['rule_id'])==c['owner'] for c in cards))
    ck('one_rule_one_owner',unique and owners_ok and registry_ok,f'cards={len(ids)} registry={reg_count}')

    # L0 source/projection binding
    rt=read(root/'prompt/PEOS_CURRENT_RUNTIME_GUARD_JP.md')
    sm=re.search(r'<!-- L0_BOOT_SHIM_SOURCE_BEGIN -->.*?<!-- L0_BOOT_SHIM_SOURCE_END -->',rt,re.S)
    binding=json.loads(read(root/'bootstrap/PEOS_L0_BOOT_SHIM_BINDING.json'))
    proj_path=root/'bootstrap/PEOS_L0_BOOT_SHIM.txt'
    l0_ok=bool(sm)
    if sm:
        sbsha=sha_bytes(sm.group(0).encode('utf-8'))
        l0_ok=l0_ok and binding['source_block_sha256']==sbsha and binding['source_canon_sha256']==sha_file(root/'prompt/PEOS_CURRENT_RUNTIME_GUARD_JP.md') and binding['projection_sha256']==sha_file(proj_path)
    proj=read(proj_path)
    forbidden=['MAGI','OPSEC','FATHER_STYLE','COORDINATE_POLICY','EVIDENCE_POLICY']
    l0_minimal=all(x not in proj for x in forbidden) and 'L0_IS_SIXTH_CANON = FALSE' in proj and 'datetime.now(ZoneInfo("Asia/Tokyo"))' in proj
    ck('l0_projection_integrity_and_minimality',l0_ok and l0_minimal,binding.get('source_block_sha256',''))

    # State split and hard gate tokens
    state_tokens=['RC_FILE_SEEN','FIVE_CANON_AVAILABLE','FIVE_CANON_INSPECTED','L0_BOOTSTRAP_BOUND','FIVE_CANON_LOADED','FIVE_CANON_VALIDATED','RUNTIME_ACTIVE_RULES_COMPILED','HOST_PRE_DISPATCH_HOOK_INSTALLED','FIRST_USER_TURN_ARMED','CURRENT_TURN_PYTHON_RECEIPT_VALID','SEMANTIC_WORK_AUTHORIZED']
    ck('state_split_complete',all(tok in rt for tok in state_tokens))
    ck('hard_gate_and_no_late_repair',all(tok in rt for tok in ['ALLOW_ONLY_ACTION_INDEX_1','no_late_repair()','HOST_BOOTSTRAP_UNAVAILABLE','receipt前のcommentary']))

    # Boot exactness
    def boot_hash(route):
        m=re.search(rf'### {route}\n\n```text\n(.*?)\n```',rt,re.S)
        return sha_bytes(m.group(1).encode('utf-8')) if m else None
    ck('father_boot_exact_hash',boot_hash('FATHER_ROUTE')==FATHER_BOOT_SHA,boot_hash('FATHER_ROUTE') or '')
    ck('mother_boot_exact_hash',boot_hash('MOTHER_ROUTE')==MOTHER_BOOT_SHA,boot_hash('MOTHER_ROUTE') or '')
    ck('boot_immutable_rule',all(x in rt for x in ['extra code-fence metadata/IDs','BOOT_NONCONFORMANCE','simple plain code block']))

    # Father ledger coverage and time fields
    ledger=[json.loads(x) for x in read(root/'admin/FATHER_DIRECT_LEDGER.jsonl').splitlines() if x.strip()]
    ledger_ids=[e['ENTRY_ID'] for e in ledger]
    time_fields=['TURN_TIME_STATUS','USER_TURN_OBSERVED_AT_JST','TIME_EVIDENCE_CLASS','TIME_AUTHORITY']
    source_entries=[e for e in ledger if e.get('SOURCE_LOCATION','').startswith('PEOS_father_session_log_2026_08_09_134902.txt#FD-')]
    source_raw=parse_father_source_entries(read(root/'source/PEOS_father_session_log_2026_08_09_134902.txt'))
    source_hashes={sha_bytes(raw.encode('utf-8')) for _,raw in source_raw}
    ledger_source_hashes={e['SHA256'] for e in source_entries}
    ck('father_direct_ledger_unique_and_time_fields',len(ledger_ids)==len(set(ledger_ids)) and all(all(k in e for k in time_fields) for e in ledger),f'count={len(ledger)}')
    ck('father_source_34_of_34',len(source_raw)==34 and len(source_entries)==34 and source_hashes==ledger_source_hashes)
    ck('current_build_father_direct_present',any(e.get('ENTRY_ID')=='FD-20260809-CURRENT-RC4-BUILD' for e in ledger))

    # Source learning / behavior
    behavior=read(root/'admin/FATHER_BEHAVIOR_MODEL.yaml')
    learning=read(root/'admin/SOURCE_LEARNING_REGISTRY.yaml')
    style_tokens=['BEH-FATHER-COUNTERPUNCH-001','BEH-FATHER-LINT-001','BEH-FATHER-EVIDENCE-001','BEH-FATHER-HUMOR-002']
    ck('father_style_model_core',all(x in behavior for x in style_tokens) and 'surface_mimicry_only: FAIL' in behavior)
    ck('source_learning_purity',all(x in learning for x in ['father_direct_utterance','father_explicitly_self_attributed_post','assistant_wording','anonymous_board_wording','authorship_expansion_to_neighbors: PROHIBITED','opsec_override: REQUIRED']))

    # Mother regression fixture and calling correction
    mt=read(root/'source/PEOS_mother_session_log_2026_08_09_130028.txt')
    mother_tokens=['CURRENT_USER_TURN_TIME_STATUS: NOT_CAPTURED_AT_FIRST_ACTION','CURRENT_TURN_PYTHON_RECEIPT: ABSENT','CURRENT_TIME_CAPTURE_ATTEMPTS: 0','TURN_TIME_INGRESS_LATCH: LOCKED_ORDER_INVALID','INGRESS_ORDER_VALID: FALSE','SEMANTIC_WORK_AUTHORIZED_UNDER_rev0.305: FALSE']
    ck('mother_ingress_regression_fixture',all(x in mt for x in mother_tokens))
    overlay=read(root/'admin/COORDINATE_OVERLAY_MAP.yaml')
    ck('mother_call_sticky', 'canonical_call: お母さん' in overlay and 'do not use ともちゃん' in overlay)

    # Output channel
    ck('artifact_stdout_suppression', 'ログを標準出力するな' in read(root/'source/PEOS_father_session_log_2026_08_09_134902.txt') and 'build directive、evidence' in rt)

    # Current build trace and live pending separation
    cur=json.loads(read(root/'tests/CURRENT_BUILD_TURN_ACTUAL_TRACE.json'))
    ck('current_build_turn_actual_trace',cur['CAPTURE_ATTEMPTS']==2 and cur['SUCCESSFUL_CAPTURE_ACTION_INDEX']==2 and cur['INTERVENING_ACTION_BEFORE_SUCCESS']=='NONE' and cur['INGRESS_ORDER_VALID'] is True)
    live=json.loads(read(root/'tests/FIVE_CANON_COLD_START_LIVE_TRACE.json'))
    ck('live_acceptance_not_fabricated',live['LIVE_HOST_ACCEPTANCE']=='PENDING' and live['RELEASE_ACCEPTANCE']=='BLOCKED' and live['OBSERVED_LIVE_TURNS']==[])
    matrix=json.loads(read(root/'tests/NEXT_SPEC_ACCEPTANCE_MATRIX.json'))
    ck('acceptance_matrix_A_to_O',len(matrix['TESTS'])==15 and [x['TEST'] for x in matrix['TESTS']]==list('ABCDEFGHIJKLMNO') and matrix['LIVE_HOST_STATE']=='PENDING')

    # Static harness with actual local Python provider, explicitly not production proof
    positives,negatives=run_harness()
    harness_ok=all(x['pass'] for x in positives) and all(x['pass'] for x in negatives)
    ck('static_harness',harness_ok,f"positive={len(positives)} negative={len(negatives)}")

    # Evidence count and README Japanese/L0 disclosure
    evidence_files=list((root/'evidence').glob('*'))
    ck('single_consolidated_evidence',len([p for p in evidence_files if p.is_file()])==1 and evidence_files[0].name=='PEOS_EVIDENCE.txt')
    readme=read(root/'README.md')
    ck('readme_japanese_and_l0_disclosure',all(x in readme for x in ['今回の主修正','L0は**第六正本ではありません**','live acceptance','father style learning']))

    # External immutable artifacts when available
    ext_ok=True; ext_detail=[]
    for name,expected in [
      ('PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip',BASELINE_SHA),
      ('PEOS_GITHUB_PACKAGE_rev0.306-RC2.zip.sha256',BASELINE_SIDE_SHA),
      ('PEOS_GITHUB_PACKAGE_rev0.306-RC3.zip',RC3_SHA),
      ('PEOS_GITHUB_PACKAGE_rev0.306-RC3.zip.sha256',RC3_SIDE_SHA),
    ]:
        p=ext/name
        if p.exists():
            got=sha_file(p); ext_ok=ext_ok and got==expected; ext_detail.append(f'{name}:{got}')
        else:
            ext_detail.append(f'{name}:NOT_PRESENT')
    ck('baseline_and_current_reference_immutability',ext_ok,';'.join(ext_detail))

    # Manifest hashes if enabled
    if not args.skip_manifest:
        try:
            man,rows=parse_manifest(root)
            man_ok=f'VERSION: {REV}' in man and f'PROJECT_LEVEL_CURRENT_REFERENCE: {CURRENT_REF}' in man and f'ACCEPTED_BASELINE_SHA256: {BASELINE_SHA}' in man
            listed=set()
            for exp,size,rel in rows:
                p=root/rel
                if not p.exists() or p.stat().st_size!=size or sha_file(p)!=exp: man_ok=False
                listed.add(rel)
            actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='PACKAGE_MANIFEST.txt'}
            man_ok=man_ok and listed==actual
            ck('manifest_hashes_all_nonmanifest_files',man_ok,f'listed={len(listed)} actual={len(actual)}')
        except Exception as e:
            ck('manifest_hashes_all_nonmanifest_files',False,repr(e))

    passed=sum(1 for c in checks if c['pass'])
    result={
      'revision':REV,
      'validator_class':'STATIC_PACKAGE_AND_CONTRACT_VALIDATOR',
      'production_live_trace_claimed':False,
      'live_host_acceptance':'PENDING',
      'release_acceptance':'BLOCKED',
      'checks_passed':passed,
      'checks_total':len(checks),
      'all_static_checks_pass':passed==len(checks),
      'active_rule_count':len(ids),
      'father_ledger_count':len(ledger),
      'static_harness_positive_count':len(positives),
      'static_harness_negative_count':len(negatives),
      'checks':checks,
      'static_harness':{'positive':positives,'negative':negatives},
    }
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['all_static_checks_pass'] else 1

if __name__=='__main__':
    sys.exit(main())
