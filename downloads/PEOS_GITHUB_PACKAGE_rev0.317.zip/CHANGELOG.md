## rev0.317 — revision and download correction

Assign the owner-requested rev0.317 to the package, current five documents, metadata and filenames. Fix download buttons to immutable verified raw-file URLs. Keep previous ZIP bytes unchanged and retain history/rev0.316 and history/rev0.315 only.

## PEOS_REV0.317_20261103（次revision未採番）

共通の論説・原則長文・独立判断を親密度から分離。MAGI三者の担当と結論前の検討・表示条件を復元。採用済み完全版設定、未接続時の会話継続、前処理後の文頭実時刻、ZIP/五正本の同等導入を統合。現行316・baseline315を維持。実モデル試験は未実施。

# rev0.316 candidate

- 25 source項目を分類し、13新規規則・4明確化・1再確認を五正本へ反映。全443規則。
- 親密度と冗談の通じやすさ、AND条件、例外、保留、回復、訂正への感謝を型分離。
- 比喩・仮定・背景補足の訂正を保持し、6私的状態と1未採用方式を分離。
- 数値スコア・固定時間・自動NLP分類・完全継承の成功を主張しない。
- 五正本5添付と過去2版315/314、公開/私的資料の分離を維持。

# rev0.315 candidate

- 18要求を五正本へ統合。全430規則、一規則一所有者。
- 共通の論説調・笑い・呆れ・自己懐疑と、利用者別前処理束縛を明確化。
- 五正本5添付、任意呼称、README後半マニュアルを維持。
- 公開版と私的根拠を分離し、歴史snapshotは314/313の2版。
- 現行314・baseline313を維持する未受入候補。実モデル・実同期の受入は未実施。

# Public export rev0.314

## Beginner installation guide and public ZIP — 2026-10-24

- Put project purpose, publication scope, authority and validation first in README, followed by a five-step installation guide requiring only the five canonical upload files and copyable, self-contained project instructions.
- Let each user specify their preferred user name; include boot-display checks, troubleshooting and a truthful path for unavailable record/sync capabilities.
- Keep developer notes below the introductory guide; package the validated public tree without original conversations, images, private state, Git metadata or embedded archives.

## Division common-core deployment profile — 2026-10-24

- Add a derived Japanese entry and hash-bound profile for shared reasoned prose, contextual laughter of two or more characters, sentence-final exasperation marking, evidence-proportional skepticism and actual short preprocessing.
- Keep one shared core for FATHER/MOTHER/GENERAL; limit relationship adapters to context and call-signs.
- Reuse the short preprocessing driver with durable per-user journal bindings, no fabricated capability receipts and no cross-coordinate father learning.
- Add synthetic integration cases and a separate paired model-replay rubric. Live host/model acceptance remains unclaimed; the five canonical documents and release authority retain their bytes and values.

## Repository cleanup — 2026-10-23

- Remove 23 obsolete files (226,255 bytes) and the resulting empty `evidence/`, `papers/`, `patch_notes/`, and `tool/` directories.
- Use the root public manifest/changelog and `tools/validate_rev0_314.py`; retire the missing-layout March manifest, duplicate rev0.312 prompt metadata, old validation reports, and rev0.305 validator.
- Keep the current five canons, their original bytes, generic runtime code, public validation, and the two required canonical history subsets.
- Record the path/hash/successor audit in `admin/OBSOLETE_FILE_CLEANUP_rev0.314.json`. Earlier inspection statements in immutable canons remain historical evidence.

## Initial public export

- Authority: current/detailed rev0.314; accepted baseline rev0.313.
- Excludes raw conversation corpora, images, direct-learning ledgers and private restore snapshots.
- Retains canonical bytes and executable generic code; replaces source-bound checks with an explicit public validation entry.
- Earlier entries below describe original distribution builds, not files included in this public tree.

# rev0.314 candidate

91 source requirements mapped to canon owners and actual event SEQ. Short
ACK-sync, boot priority and scoped pause/resume supersede unconditional full
readback in normal operation. Completed work, correction provenance, attribution,
GitHub HOLD and logification pairing gain executable supporting guards. Retained
history rolls to rev0.313/rev0.312 with no nested history or archive payloads.

---
# rev0.313 retention correction

- 過去版はrev0.312・rev0.311の2版へ限定。両版の内部からも旧履歴を除去。
- 全ての埋め込みarchiveを展開済み資料とflat snapshotに置換し、ZIPの再帰を禁止。
- 49件の原文入力を維持。現行共通部品の安定pathへ参照を更新。
- 元archive validatorと整理tree validatorの適用範囲を分離。
- current/accepted/同期reported状態・private ledger非再実行は維持。

---
以下は変更の系譜であり、旧release payloadではない。

# CHANGELOG

## PEOS-REV0.312-CANDIDATE-20261007-105524-JST — TARGET_REVISION_LABEL: rev0.312

### Priority source
- project-level current identity: `rev0.311`
- current physical SHA-256: `e1529b3430dab141cffa304ecb374b58b08e61288fc742602c762633d0e9f275`
- accepted detailed reference: `PEOS_GITHUB_PACKAGE_rev0.310.zip`
- father log SHA-256: `f667cf506c749d5ab0c969fbe5151b99f52fc8d01c85aa4bfc4ec2e33dcbc3e2`
- directive SHA-256: `660f6e5a5656b09f3018de02897096ce2aedbd893b563400013c04dc6da32c3f`
- source bundle SHA-256: `6278a7a6887f7911e9f2cfdfeb5c7f2e11287038edfc4ac5156b41941bd2628c`

### Fix-forward deltas
- typed incident/source/status continuity graph with monotonic correction state
- confirmed/unresolved medical separation and patient-side epistemic boundary
- billing category versus bedside chronology guard
- anonymous-evidence compartment and father-vocabulary exclusion
- mobility/device current-state continuity for HG-EWC9000
- product/listing/price/stock/compatibility state separation
- live merchant stock recheck and full battery compatibility gate
- physical fixture inspection and artifact-class routing
- session-handoff two-root-TXT topology kept local to its class
- universal time gate retained across all new domain routes
- 39 candidate rules added; registry/canon total 287 unique rules
- CT-01〜15 static harness plus inherited 13+12+10+10 nonregression cases

### Release control
- candidate remains `NOT_OPERATIVE / NOT_ACCEPTED / NOT_SELF_ACCEPTED`
- project current remains rev0.311; accepted detailed reference remains rev0.310
- private live ledger excluded from the general package
- current build turn remains `PRE_DISPATCH_GATE_BYPASS / TIME_INGRESS_ORDER_INVALID / NO_LATE_REPAIR`
- live stock, live host conformance and father acceptance remain `PENDING`

## PEOS-REV0.311-CANDIDATE-20260913-171938-JST — TARGET_REVISION_LABEL: rev0.311

### Priority source
- project-level current identity: `rev0.310`
- current physical SHA-256: `3ebad22dc4a0f1f70e1e14b1b05cadeae32c17427176f618b56105060e001431`
- accepted detailed reference: `PEOS_GITHUB_PACKAGE_rev0.309.zip`
- father log SHA-256: `32dfe78bdab5f1e559c83cf2e2ec4ed65ad5696a093e202ba7f9ccc97a5d0772`
- directive SHA-256: `319c957429db8692cdc8f0832d46497f21ac9f36565c4232ac4300a1e384b9a6`
- source bundle SHA-256: `f85243c932eb0ae3b0eb81fca9f4c32ad7008e6b5d9c8f29975a60a9f2860448`

### Fix-forward deltas
- universal root pre-dispatch dispatcher for 13 USER-turn routes
- persist/readback/same-timestamp verification before work permit
- explicit non-exemption for casual chat and artifact operations
- capability-truthful Python-reference/trusted-alternate capture adapters
- typed capture, persistence, bypass and missing-coverage failure classes
- ledger coverage auditor and strict user-error causal attribution
- no historical timestamp synthesis and no success narration without execution
- mandatory Shine Muscat regression fixture and UTG-01〜13 harness
- 27 candidate rules added; registry/canon total 248 unique rules

### Release control
- candidate remains `NOT_OPERATIVE / NOT_ACCEPTED / NOT_SELF_ACCEPTED`
- project current remains rev0.310; accepted detailed reference remains rev0.309
- missing mother-session physical log is a declared evidence gap
- private live ledger excluded from the general package
- current build turn remains `PRE_DISPATCH_GATE_BYPASS / NO_LATE_REPAIR`
- live universal route interception and father acceptance remain `PENDING`

## PEOS-REV0.310-CANDIDATE-20260904-042814-JST — TARGET_REVISION_LABEL: rev0.310

### Priority source
- project-level current canon: `rev0.309`
- current physical package SHA-256: `5cc56551739059d0ba0cda8d1de26907343554c7ce9aca97921c1dcedb9c1888`
- accepted baseline: `PEOS_GITHUB_PACKAGE_rev0.308.zip`
- accepted baseline SHA-256: `b62f418a3803d02206d619671dc70a997af58e5bd07a0641d17b032ab9f9ae96`
- father degradation log SHA-256: `d43f378fabce9300a3bd65f182fc8554b9965ca52829f6896dffc9decac8a3db`
- treatment directive SHA-256: `0368326137c41a7b2cfc5eb2c09b7f3745084027ba9e9045b797c781c1082b83`
- degradation source bundle SHA-256: `84ad0e51a49f90db52062fae8262b043c8e0c1508cd7266b8f452f5bcee255f3`

### Fix-forward deltas
- separate source/read/sync/project/continuity/runtime/ledger/boot/persistence states
- positive-evidence boot gate and no false sync/ready claims
- atomic per-turn receipt/persistence/readback/prefix transaction driver
- exact first-text JST prefix with same-receipt binding
- persistence-unavailable DEGRADED path; no ephemeral fallback or backfill
- next-four-successful-turn correction constraint store
- timestamp/correction/authority/core/density/generic-override precommit audit
- next-turn degradation detection and stale seq36 fixture
- observable reasoning-quality gate, independent of UI thinking duration
- AT-01 through AT-12 static integration harness
- live/static/father acceptance evidence type separation
- 30 candidate rules added; registry/canon total 221 unique rules

### Controlled bisect
- accepted rev0.308 and physical rev0.309 time-ledger implementation files are byte-identical
- rev0.309 has 23 added candidate rules and zero removals versus rev0.308
- selected branch: `FIX_FORWARD_FROM_CURRENT_REV0.309`
- strong provisional root cause: `HOST_RUNTIME_BINDING_DROPOUT / BOOT_STATE_FALSE_POSITIVE`

### Release control
- candidate remains `NOT_OPERATIVE / NOT_ACCEPTED / NOT_SELF_ACCEPTED`
- project current remains rev0.309; accepted baseline remains rev0.308
- private live ledger excluded from general package
- declared missing `14191.png` remains a typed gap; no fabrication
- explicit versioned host write/readback observed once; automatic per-turn binding not proven
- live 10-turn and father external acceptance remain `PENDING`
- current build turn remains `ORDER_INVALID / NO_LATE_REPAIR / NON_ACCEPTANCE_OBSERVATION`

## PEOS-REV0.309-CANDIDATE-20260901-193512-JST — TARGET_REVISION_LABEL: rev0.309

### Priority source
- project-level current canon: `rev0.308`
- accepted baseline: `PEOS_GITHUB_PACKAGE_rev0.307.zip`
- source package SHA-256: `b62f418a3803d02206d619671dc70a997af58e5bd07a0641d17b032ab9f9ae96`
- corrected father log SHA-256: `98d37d29df7f1fe2670229220ec31ab3994040509c5ab86deec7863af097d037`
- REGEN directive SHA-256: `152bc9f4d017fb9085e7e2e4acc16adb8e1f12b67f0af95f0e0b5cba52e925fd`
- corrected source bundle SHA-256: `b414a090dfec34b1f6f1232a949bb513de368443c2ff43b748702581394f7522`
- old 19:09:59 generation: `SUPERSEDED / HISTORICAL_ONLY`

### Fix-forward deltas
- single `GLOBAL_PEOS_RESPONSE_CORE`
- thin `RELATION_CONTEXT_ADAPTER`
- archive/evidence and runtime-restore two-layer logs
- typed assistant-verbatim gaps without fabricated transcript
- response-density hard gate from father correction `お前の応答が薄いな`
- artifact-delivery personality survival invariant
- generalized DO_NOT_RESURRECT state gate
- explicit image-generation intent gate
- typed anonymous-identity hypothesis boundary
- historical authority snapshot no-rollback guard
- immediate ledger-persistence ordering rule retained with typed failures
- STYLE-RESTORE-A through J static acceptance harness

### Release control
- candidate remains NOT_ACCEPTED / NOT_SELF_ACCEPTED
- project current canon remains rev0.308
- accepted baseline remains rev0.307
- father-private live ledger and whole source bundle excluded from general package
- live style restoration and father external acceptance remain PENDING

## PEOS-REV0.308-CANDIDATE-20260824-012834-JST — TARGET_REVISION_LABEL: rev0.308

### Source
- project-level current reference: `rev0.307`
- accepted baseline: `PEOS_GITHUB_PACKAGE_rev0.306.zip`
- source package SHA-256: `1535332c132a47e150bf3077327760efecbf031a9315dcecfc7bcddf094cb28c`
- father log SHA-256: `d203310dd8a05a1a801eefeb8b418a1d74ef4a62a1c41449c915afd1e470747c`
- directive SHA-256: `7d1d20ba3c63b9193a3df9db0f59c1fc32a1abaa60d3c143f3a42cbc21c65c37`
- source bundle SHA-256: `ea3919267a5a0970eb6ff3e75e278a88f366d8832e2b1a2eeac22534a2a809fc`

### Fix-forward deltas
- persistent `PEOS_TURN_TIME_LEDGER` contract
- receipt/visible/ledger/log same-value binding
- capture/persistence state separation
- logical append-only history over guarded host version replacement
- read-only mount typed fallback
- post-write verification and idempotency
- ledger-first log reconstruction and missing-time field omission
- five-canon/supporting-state boundary
- father-private ledger exclusion from general package
- TIME-LEDGER-A through J static harness

### Release control
- candidate remains NOT_ACCEPTED / NOT_SELF_ACCEPTED
- current project reference remains rev0.307
- accepted baseline remains formal rev0.306
- live multi-turn/persistent-store/restart acceptance remains PENDING

## PEOS-REV0.307-CANDIDATE-20260823-211106-JST — TARGET_REVISION_LABEL: rev0.307

### Source
- current canon/base reference: `rev0.306`
- source package SHA-256: `f2eb04385feb06f8dc920472463f47c3fca1576554204813040d4753cb37b332`
- father log SHA-256: `cd352c85bdc18d686262a43420aa1eeee9e84d82c664d29536eb0ddd17c4dfe6`
- directive SHA-256: `d01a7b19efb2cc67e57f0bbf86054a2bf209c224818c9ef90e0d2dd40009fb89`
- source bundle SHA-256: `e5cc37e60a01f350bd27d75532a2f18212107f6879dcfdf4acf46a2a91d65a89`

### Candidate deltas
- formalized `ログファイル化`
- authority-gated log delivery
- per-turn JST ingress + father/mother display contract
- plain UTF-8 transcript and missing-time field omission
- per-body hash metadata prohibition; file-level integrity retained
- evidence physical-source binding
- quote/speaker context separation
- dynamic current-fact freshness boundary
- reminder state machine / idempotency / no replay / privacy
- source-learning quote-subspan guard
- travel/medical/private continuity no-replay

### Release control
- revision number not assigned by build system
- current/operative canon remains rev0.306
- candidate is NOT_ACCEPTED / NOT_SELF_ACCEPTED

## rev0.307 revision assignment — 2026-08-23
- Father assigned the previously unassigned candidate to `rev0.307`.
- Future sequential auto-increment is authorized unless father explicitly overrides the target revision.
- Revision assignment does not self-accept the candidate; operative/current remains rev0.306 pending explicit acceptance.
- Original source bundle/log/directive files remain byte-identical.
- Prior unassigned physical candidate remains external immutable audit artifact.
# rev0.313 full redelivery

- Fix forward from complete rev0.312; current remains rev0.312 and accepted/detailed reference rev0.311.
- Preserve all 287 inherited rule identities and add 34 candidate rules across five canons.
- Define pre-response durable commit/sync/new-file-ID verification and distinct PASS/DEGRADED/FAIL outcomes.
- Preserve ten normal consecutive PASS, emergency priority, scoped father exemption and no late promotion.
- Preserve source-reported sync without replay, 17 user bodies, quote exclusions and typed clinical/family continuity.
- Add PB-01..26 and retain all 60 inherited behavior cases. Live/father acceptance remains pending.
- Retain every historical package ZIP binary in full; no lightweight edition or archive omission.
- Reconstructed delivery has its own fingerprint; byte identity with the unavailable prior rev0.313 ZIP is not claimed.

